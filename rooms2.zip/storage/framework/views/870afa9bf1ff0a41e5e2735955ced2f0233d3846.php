<!-- Name Ar Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('name_ar', __('models/cards.fields.name_ar').':'); ?>

    <?php echo Form::text('name_ar', null, ['class' => 'form-control', 'maxlength' => 255, 'maxlength' => 255]); ?>

</div>

<!-- Name En Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('name_en', __('models/cards.fields.name_en').':'); ?>

    <?php echo Form::text('name_en', null, ['class' => 'form-control', 'maxlength' => 255, 'maxlength' => 255]); ?>

</div>

<!-- Job Title Ar Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('job_title_ar', __('models/cards.fields.job_title_ar').':'); ?>

    <?php echo Form::text('job_title_ar', null, ['class' => 'form-control', 'maxlength' => 255, 'maxlength' => 255]); ?>

</div>

<!-- Job Title En Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('job_title_en', __('models/cards.fields.job_title_en').':'); ?>

    <?php echo Form::text('job_title_en', null, ['class' => 'form-control', 'maxlength' => 255, 'maxlength' => 255]); ?>

</div>
    <?php echo Form::hidden('membership_number', '0000000'); ?>



<!-- Phone1 Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('phone1', __('models/cards.fields.phone1').':'); ?>

    <?php echo Form::text('phone1', null, ['class' => 'form-control', 'maxlength' => 255, 'maxlength' => 255]); ?>

</div>

<!-- Phone2 Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('phone2', __('models/cards.fields.phone2').':'); ?>

    <?php echo Form::text('phone2', null, ['class' => 'form-control', 'maxlength' => 255, 'maxlength' => 255]); ?>

</div>

<!-- Email Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('email', __('models/cards.fields.email').':'); ?>

    <?php echo Form::email('email', null, ['class' => 'form-control', 'maxlength' => 255, 'maxlength' => 255]); ?>

</div>

<!-- Website Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('website', __('models/cards.fields.website').':'); ?>

    <?php echo Form::text('website', null, ['class' => 'form-control', 'maxlength' => 255, 'maxlength' => 255]); ?>

</div>



<style>
    #preview {
        max-width: 100px;
        //  display: none;
    }
</style>
<div class="form-group col-sm-6">
    <?php echo Form::label('image',__('models/cards.fields.image').':' ); ?> <br>
    <?php echo Form::label('image', 'Upload', ['class' => 'btn-primary btn btn-block ']); ?>

    <?php echo Form::file('image', ['style' => 'display:none;', 'id' => 'image', 'onchange' => 'previewImage(event)']); ?>

    <img id="preview" src=<?php echo e(Route::is('cards.edit') ? asset('storage/profile/' . $card->image) : ''); ?>>

</div>
<?php $__env->startPush('img'); ?>
    <script>
        function previewImage(event) {
            var reader = new FileReader();
            reader.onload = function() {
                var output = document.getElementById('preview');
                output.src = reader.result;
                output.style.display = "block";
            }
            reader.readAsDataURL(event.target.files[0]);
        }
    </script>
<?php $__env->stopPush(); ?>



<!-- Category Id Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('category_id', __('models/cards.fields.category_id').':'); ?>

    <?php echo Form::select('category_id', $categories,null,['class' => 'form-control']); ?>

</div>
<!-- Category Id Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('city', __('models/cards.fields.city').':'); ?>

    <?php echo Form::select('city', $cities,null,['class' => 'form-control']); ?>

</div>

<!-- Company En Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('company_en', __('models/cards.fields.company_en').':'); ?>

    <?php echo Form::text('company_en', null, ['class' => 'form-control', 'maxlength' => 255, 'maxlength' => 255]); ?>

</div>
<!-- Company En Field -->
<div class="form-group col-sm-6">

    <?php echo Form::label('company_ar', __('models/cards.fields.company_ar').':'); ?>

    <?php echo Form::text('company_ar', null, ['class' => 'form-control', 'maxlength' => 255, 'maxlength' => 255]); ?>


</div>

<!-- Company Email Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('company_email', __('models/cards.fields.company_email').':'); ?>

    <?php echo Form::text('company_email', null, ['class' => 'form-control', 'maxlength' => 255, 'maxlength' => 255]); ?>

</div>





<div class="form-group col-sm-6">
    <?php echo Form::label('identity_file1', __('models/cards.fields.identity_file1').':'); ?>

    <?php echo Form::label('identity_file1', 'Upload', ['class' => 'btn-primary btn btn-block ']); ?>

    <?php echo Form::file('identity_file1', ['style' => 'display:none;', 'id' => 'identity_file1', 'onchange' => 'fileName1(event)']); ?>

    <span id="filename" ><?php echo e(Route::is('cards.edit') ?  $card->identity_file1: ''); ?> </span>

</div>
<?php $__env->startPush('filename1'); ?>
<script>
    function fileName1(event) {
        var reader = new FileReader();
        reader.onload = function() {

            var output = document.getElementById('filename');
            output.textContent = event.target.files[0].name;
            output.style.display = "block";
        }
        reader.readAsDataURL(event.target.files[0]);

    }
</script>
<?php $__env->stopPush(); ?>

<div class="form-group col-sm-6">
    <?php echo Form::label('identity_file2', __('models/cards.fields.identity_file2').':'); ?>

    <?php echo Form::label('identity_file2', 'Upload', ['class' => 'btn-primary btn btn-block ']); ?>

    <?php echo Form::file('identity_file2', ['style' => 'display:none;', 'id' => 'identity_file2', 'onchange' => 'fileName2(event)']); ?>

    <span id="filename2" ><?php echo e(Route::is('cards.edit') ?  $card->identity_file1: ''); ?> </span>

</div>

<!-- Facebook Url Field -->
<div class="form-group col-sm-6">

    <?php echo Form::label('facebook_url', __('models/cards.fields.Social_media').':'); ?>


    <div class="input-group mb-3">
        <div class="input-group-prepend">
          <span class="input-group-text" style="width : 50px; justify-content:center; "> <i class="fa fa-facebook-f"></i></span>
        </div>
        <?php echo Form::text('facebook_url', null, ['class' => 'form-control', 'maxlength' => 255, 'maxlength' => 255]); ?>

    </div>
    <div class="input-group mb-3">
        <div class="input-group-prepend">
          <span class="input-group-text" style="width : 50px; justify-content:center; "> <i class="fa fa-twitter"></i></span>
        </div>
        <?php echo Form::text('twitter_url', null, ['class' => 'form-control', 'maxlength' => 255, 'maxlength' => 255]); ?>

    </div>
    <div class="input-group mb-3">
        <div class="input-group-prepend">
          <span class="input-group-text" style="width : 50px; justify-content:center; "> <i class="fa fa-linkedin"></i></span>
        </div>
        <?php echo Form::text('linkedin_url', null, ['class' => 'form-control', 'maxlength' => 255, 'maxlength' => 255]); ?>

    </div>
    <div class="input-group mb-3">
        <div class="input-group-prepend">
          <span class="input-group-text" style="width : 50px; justify-content:center; "> <i class="fa fa-instagram"></i></span>
        </div>
        <?php echo Form::text('instagram_url', null, ['class' => 'form-control', 'maxlength' => 255, 'maxlength' => 255]); ?>

    </div>
    <div class="input-group mb-3">
        <div class="input-group-prepend ">
          <span class="input-group-text " style="width : 50px; justify-content:center; "> <i  class="fa fa-youtube"></i></span>
        </div>
        <?php echo Form::text('youtube_url', null, ['class' => 'form-control', 'maxlength' => 255, 'maxlength' => 255]); ?>

    </div>


</div>
<?php $__env->startPush('filename2'); ?>
    <script>
        function fileName2(event) {
            var reader = new FileReader();
            reader.onload = function() {

                var output = document.getElementById('filename2');
                output.textContent = event.target.files[0].name;
                output.style.display = "block";
            }
            reader.readAsDataURL(event.target.files[0]);

        }
    </script>
<?php $__env->stopPush(); ?>

 <?php echo Form::hidden('paid', 0); ?>



<?php /**PATH C:\laragon\www\rooms\resources\views/cards/fields.blade.php ENDPATH**/ ?>