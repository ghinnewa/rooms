<li class="nav-item">
    <a href="<?php echo e(route('cards.index')); ?>"
       class="nav-link <?php echo e((Request::is('cards') )? 'active' : ''); ?>">
        <p>Cards</p>
    </a>
</li>


<li class="nav-item">
    <a href="<?php echo e(route('users.index')); ?>"
       class="nav-link <?php echo e(Request::is('users*') ? 'active' : ''); ?>">
        <p>Users</p>
    </a>
</li>


<li class="nav-item">
    <a href="<?php echo e(route('categories.index')); ?>"
       class="nav-link <?php echo e(Request::is('categories*') ? 'active' : ''); ?>">
        <p>Categories</p>
    </a>
</li>

<li class="nav-item">
    <a href="<?php echo e(route('cards.requests')); ?>"
       class="nav-link <?php echo e(Request::is('requests') ? 'active' : ''); ?>">
        <p>Requests</p>
    </a>
</li>


<?php /**PATH C:\laragon\www\rooms\resources\views/layouts/menu.blade.php ENDPATH**/ ?>