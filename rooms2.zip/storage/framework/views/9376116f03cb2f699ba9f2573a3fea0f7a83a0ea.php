<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <script src="https://kit.fontawesome.com/69393ee716.js" crossorigin="anonymous"></script>

</head>
<style>
    @import  url('https://fonts.googleapis.com/css2?family=Almarai:wght@300;700;800&display=swap');
</style>
<style>
    body {
        box-sizing: none;
        padding: 0;
        margin: 0;
        font-family: Almarai, sans-serif;
    }

    .card {
        width: 90%;
        height: 90%;
        border-radius: 20px;
        background: #ffffff;
        box-shadow: rgba(0, 0, 0, 0.19) 0px 10px 20px, rgba(0, 0, 0, 0.23) 0px 6px 6px;
        display: flex;
        justify-content: space-around;
        align-items: center;


    }

    .container {
        width: 100vw;
        height: 100vh;
        display: flex;
        justify-content: center;
        align-items: center;
    }
</style>

<body>

    <div class="container " >

        <div class=" card">

<?php if(!empty($card)): ?>
<?php if($card->paid): ?>
            <div class="content" style="text-align: center;">

                
                <h1><?php echo e($card->name_ar); ?></h1>
                <h3><?php echo e($card->job_title_ar); ?></h3>

                <h1><?php echo e($card->name_en); ?></h1>
                <h3><?php echo e($card->job_title_en); ?></h3>

                
                <h4>mimber ship No. : <?php echo e($card->membership_number); ?> :رقم العضوية </h4>

                
                <p> <?php echo e($card->phone1); ?><i class="fa fa-solid fa-phone"></i>
                </p>

                
                <p><?php echo e($card->phone2); ?><i class="fa fa-solid fa-phone"></i>
                </p>

                
                <p><?php echo e($card->email); ?></p>
                
                <p><?php echo e($card->website); ?></p>



            </div>
            <div class="images">

                <!-- Image Field -->

                
                <p><img src="<?php echo e(asset('storage/profile/' . $card->image)); ?>"
                        style="width:350px; height:400px; object-fit:cover;" class="img-fluid" alt=""></p>
            </div>
<?php else: ?>

<div> <h1> هذا العضو ليس مسجلا رسميا ضمن قائمة الاعضاء </h1></div>
<?php endif; ?>
<?php else: ?>
<div> <h1>هذا العضو غير موجود  </h1></div>
<?php endif; ?>
        </div>
    </div>

</body>

</html>
<?php /**PATH C:\laragon\www\rooms\resources\views/card.blade.php ENDPATH**/ ?>