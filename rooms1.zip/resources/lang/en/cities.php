<?php

return [

"Tripoli" =>  "Tripoli",
"Benghazi" =>  "Benghazi",
"Misrata" =>  "Misrata",
"Zawiya" =>  "Zawiya",
"Bayda" =>  "Bayda",
"Gharyan" =>  "Gharyan",
"Tobruk" =>  "Tobruk",
"Ajdabiya" =>  "Ajdabiya",
"Zliten" =>  "Zliten",
"Derna" =>  "Derna",
"Sabha" =>  "Sabha",
"Khoms" =>  "Khoms",
"Sabratha" =>  "Sabratha",
"Zuwara" =>  "Zuwara",
"Kufra" =>  "Kufra",
"Marj" =>  "Marj",
"Tocra" =>  "Tocra",
"Tarhuna" =>  "Tarhuna",
"Sirte" =>  "Sirte",
"Msallata" =>  "Msallata",
"Bani Walid" =>  "Bani Walid",
"Jumayl" =>  "Jumayl",
"Sorman" =>  "Sorman",
"Al Gseibat" =>  "Al Gseibat",
"Shahhat" =>  "Shahhat",

];
