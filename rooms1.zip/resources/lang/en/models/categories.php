<?php

return array (
  'singular' => 'Category',
  'plural' => 'Categories',
  'fields' => 
  array (
    'id' => 'Id',
    'name_ar' => 'Name Ar',
    'name_en' => 'Name En',
    'image' => 'Image',
    'deleted_at' => 'Deleted At',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
