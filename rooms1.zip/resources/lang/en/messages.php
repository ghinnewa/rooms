<?php

return [

    'retrieved' => ':model retrieved successfully.',
    'saved'     => ':model saved successfully.',
    'updated'   => ':model updated successfully.',
    'deleted'   => ':model deleted successfully.',
    'not_found' => ':model not found',

];
