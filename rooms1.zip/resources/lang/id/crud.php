<?php

return [
    'add_new'      => 'Tambah baru',
    'cancel'       => 'Membatalkan',
    'save'         => 'Menyimpan',
    'edit'         => 'Sunting',
    'detail'       => 'Detail',
    'back'         => 'Kembali',
    'action'       => 'Tindakan',
    'id'           => 'Indo',
    'created_at'   => 'Dibuat di',
    'updated_at'   => 'Diperbarui Pada',
    'deleted_at'   => 'Dihapus At',
    'are_you_sure' => 'Apa kamu yakin?',
];
