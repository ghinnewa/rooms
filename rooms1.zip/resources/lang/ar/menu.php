<?php

return [
    'application' => 'التطبيق',
    
];
