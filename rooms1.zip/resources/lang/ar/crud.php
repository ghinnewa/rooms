<?php

return [


    'add_new'      => 'اضافة',
    'cancel'       => 'الغاء',
    'save'         => 'حفظ',
    'edit'         => 'تعديل',
    'detail'       => 'تفاصيل',
    'back'         => 'عودة',
    'action'       => 'عمليات',
    'upload'       => 'ادراج',
    'appname'       => 'بلديتي',
    'solved'       => 'تم الحل',
    'id'           => 'رقم',
    'column'           => 'الحقول',
    'columns'           => 'الحقول',
    'clear'           => 'مسح الكل',
    'created_at' => 'تاريخ الانشاء',
    'selectoption' => 'قم بتحديد الخيار ',
    'and' => 'و',
    'users' => 'متطوعين',
    'updated_at' => 'تاريخ التعديل',
    'deleted_at'   => 'تاريخ الحذف',
    'are_you_sure' => 'هل انت متاكد؟',
    'reset' => 'اعادة تعيين الخريطة',
    'yes' => 'موافق',
    'no_service_to_show'=>'لا يوجد خدمات ضمن نفس فئة المنشأة'

];
