<?php

return [

    "Tripoli"=> "طرابلس",
    "Benghazi"=> "بنغازي",
    "Misrata"=> "مصراتة",
    "Zawiya"=> "الزاوية",
    "Bayda"=> "البيضاء",
    "Gharyan"=> "غريان",
    "Tobruk"=> "طبرق",
    "Ajdabiya"=> "اجدابيا",
    "Zliten"=> "زليتن",
    "Derna"=> "درنة",
    "Sabha"=> "سبها",
    "Khoms"=> "الخمس",
    "Sabratha"=> "صبراتة",
    "Zuwara"=> "زوارة",
    "Kufra"=> "الكفرة",
    "Marj"=> "المرج",
    "Tocra"=>  "توكرة",
    "Tarhuna"=>  "ترهونة",
    "Sirte"=>  "سرت",
    "Msallata"=>  "مسلاتة",
    "Bani Walid"=>  "بني وليد",
    "Jumayl"=>  "الجميل",
    "Sorman"=>  "صرمان",
    "Al Gseibat"=>  "القصيبات",
    "Shahhat"=>  "شحات",

];
